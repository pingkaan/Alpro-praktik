#5220411196 Isna Rafif Kautsar
#LIST kasus

list_motor=['honda', 'yamaha', 'ducati', 'suzuki', 'aprilia', 'kawasaki']
while True:
    print('===================================')
    print('Menu Pilihan : ')
    print('1. Cetak Data')
    print('2. Tambah Elemen ke Motor')
    print('3. Edit data di Motor')
    print('4. Hapus data di Motor')
    print('5. Mengurutkan Data')
    print('6. Nilai Terbesar')
    print('7. Nilai Terkecil')
    print('8. Keluar')
    print('===================================')
    pilih=int (input('Pilih menu : '))
    if pilih==1:
        print('===================================')
        print('Data di list motor = ')
        print(list_motor)
    elif pilih==2: 
        print('===================================')
        print('Tambah Elemen di dalam list motor  ')
        data=str(input('Masukkan data yang akan ditambahkan : '))
        pos=int(input('Tambah data di posisi : '))
        a=int(len(list_motor))
        if((pos<0) or (pos>a)):
            print('Posisi salah')
        else:
            list_motor.insert(pos,data)
            print('Data berhasil ditambahkan')
    elif pilih==3:
        print('Edit data di list Motor ')
        pos=int(input('Edit data di posisi : '))
        a=int(len(list_motor))
        if((pos<0) or (pos>a)):
            print('Posisi salah')
        else:
            print('Data motor yang akan diedit = ',list_motor[pos])
            data=str(input('Masukkan data Motor yang baru : '))
            list_motor[pos]=data
            print('Data motor berhasil diedit')
    elif pilih==4:
        print('Hapus data yang di list Motor')
        pos=int(input('Edit data di posisi = '))
        a=int(len(list_motor))
        if((pos<0) or (pos>a)):
            print('Posisi salah')
        else:
            print('Anda berhasil menghapus data ke = ',pos,'Yaitu : ',list_motor[pos])
            del(list_motor[pos])
    elif pilih==5:
        print('===================================')
        print('Data sebelum diurutkan : ')
        print(list_motor)
        print('data sesudah diurutkan : ')
        list_motor.sort()
        print(list_motor)
    elif pilih==6:
        print('===================================')
        print('Data terbesar di list Motor = ',max(list_motor))
    elif pilih==7:
        print('===================================')
        print('Data terkecil di list Motor = ',min(list_motor))
    else:
        print('===================================')
        print('sudah selesai')
        break