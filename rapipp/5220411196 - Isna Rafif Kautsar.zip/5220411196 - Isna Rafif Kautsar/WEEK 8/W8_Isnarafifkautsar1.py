#5220411196 Isna Rafif Kautsar
#LIST

list1=[1,2,3,4,5,6,7,8,9]
x=len(list1)
print('Data di dalam list')
for i in range(x):
    print('list ke ',i,' ',list[i])
print(list1)
for y in list1:
    print(y,end=' ')

#update data
print('\n\nupdate nilai di list')
i=int(input('ubah data ke berapa? '))
print('data ke ',i,'adalah ',list1[i])
list1[i]=int(input('Masukkan data yang baru '))
print(list1)

#delete data
print('\nmenghapus data di list ')
i=int(input('Hapus data ke berapa? '))
print('data ke ',i,'adalah ',list1[i])
del list1[i]
print('data sudah dihapus')
print(list1)
print('data terbesar dalam list adalah ',max(list1))
print('data terkecil dalam list adalah ',min(list1))

#slicing list
print('\nmengurutkan data di list')
list1.sort()
print(list1)
print('jumlah anggota list ',len(list1))
print('slicing')
print(list1[1])
print(list1[:3])
print(list1[:])
print(list1[::-1])
print(list1[::-2]) 