#5220411196 - Isna Rafif Kautsar

print("Menghitung profit and loss")
income=float(input("masukkan pendapatan anda = "))
cost=float(input("masukkan pengeluaran anda = "))
if(income>cost):
    profit= income-cost
    print("keuntungan diperoleh Rp = ",profit)
elif(income<cost):
    loss= cost-income
    print("Kerugian yang diperoleh Rp = ",loss)
elif(income==cost):
    print("Anda tidak memiliki keuntungan atau kerugian")
print("Thank You")
