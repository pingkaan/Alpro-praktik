#5220411196 - Isna Rafif Kautsar

#mengecek kondisi sederhana
nama=str(input(" siapa namamu? "))
nilai1=int(input("masukkan nilai Alpro Teori = "))
nilai2=int(input("masukkan nilai Alpro Praktek = "))
if((nilai1<0) or (nilai1>100) or (nilai2<0) or (nilai2>100)):
    print("Nilai yang di inputkan ada yang tidak valid")
else:
    if((nilai1>=75) and (nilai2>=70)):
        print("Nama Mahasiswa = ", nama)
        print("Nilai Alpro Teori = ", nilai1)
        print("Nama Mahasiswa = ", nilai2)
        print("Selamat = ",nama,"anda lulus Alpro semester ini")
    else:
        print("maaf saudara = ",nama, "anda harus ikut remidi Alpro")