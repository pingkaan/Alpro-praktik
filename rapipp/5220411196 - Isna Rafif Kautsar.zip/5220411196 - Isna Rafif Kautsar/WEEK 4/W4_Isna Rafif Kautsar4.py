#5220411196 - Isna Rafif Kautsar

print("mendeteksi status kesehatan seseorang")
nama=str(input("masukkan nama = "))
tekanan_darah=int(input("masukkan tekanan darah anda = "))
if(tekanan_darah>300):
    status1="Hipertensi Akut"
elif((tekanan_darah>=150) and (tekanan_darah<=300)):
    status1="hipertensi ringan"
elif((tekanan_darah>=100) and (tekanan_darah<150)):
    status1="Normal"
else:
    status1="Hipotensi"

#kadar gula darah

gula_darah=int(input("masukkan kadar gula darah = "))
if(gula_darah>300):
    status2="Diabet"
elif((gula_darah>=120) and (gula_darah<=300)):
    status2="waspada diabet"
else:
    status2="Normal"

if((status1=="Normal") and (status2=="Normal")):
    status3="Sehat"
else:
    status3="Kurang sehat"

print("Nama Pasien = ",nama)
print("tekanan darah pasien (status1)= ",status1)
print("kadar gula darah pasien (status2)= ",status2)
print("keseluruhan (status3)    = ",status3)   
print("Terimakasih")