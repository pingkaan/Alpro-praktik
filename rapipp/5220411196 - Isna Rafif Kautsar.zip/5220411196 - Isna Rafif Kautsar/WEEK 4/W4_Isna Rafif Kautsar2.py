#5220411196 -  Isna Rafif Kautsar

print("mengecek status penerima BLT")
nama=str(input("masukkan nama = "))
umur=int(input("masukkan umur = "))
status_blt=False
if(umur<18):
    ss=int(input("Pilih status sekolah 1. sekolah 0. Tidak sekolah --> "))
    if(ss==0):
        status_blt=True
    else:
        status_blt=False
else: #blok usia >=18
    sb=int(input("Pilih status pekerjaan 1. Bekerja 0. Tidak bekerja --> "))
    if(sb==0):
        status_blt=True
    else:
        inkam=float(input("masukkan jumlah penghasilan Rp "))
        tg=int(input("masukkan jumlah tanggungan = "))
        rasio=inkam/tg
        if(rasio>=300000):
            status_blt=False
        else:
            status_blt=True
#after if
# #mencetak hasil
print("nama     =    ",nama)
print("Umur     =    ",umur)
if(status_blt==True):
    print("anda berhak atas BLT")
else:
    print("anda tidak berhak atas BLT")
#afterif
print("Arigatou")    