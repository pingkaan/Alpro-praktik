#5220411196 - Isna Rafif Kautsar

from W7_fungsi import jarak_tempuh
from W7_fungsi import bahan_bakar_awal
from W7_fungsi import bahan_bakar_akhir
from W7_fungsi import isi_bahan_bakar


print('Responsi Alpro 1')
print('Studi Kasus Penerbangan Pesawat Terbang')
print('==========================================')
Lanjut=True
jarak=0
isi=0
while(Lanjut):
    print('Pilih Menu')
    print('1. Take Off')
    print('2. Periksa Bahan Bakar')
    print('3. Isi Bahan Bakar')
    print('4. Maintenance ke Bengkel')
    print('5. Selesai')
    pilih=int(input('Pilih Menu --->  '))
    if(pilih==1):
        print('Anda akan melakukan penerbangan')
        print('Bensin akan berkurang!')
        jarak=int(input('Masukkan Jarak tempuh Penerbangan(km) = '))
        print('Pesawat bepergian sejauh = ',jarak,'km')
        print('bahan bakar terpakai = ',jarak_tempuh(jarak),'L')

    elif(pilih==2):
        print('Periksa bahan bakar')
        print('Bahan bakar awal = ',bahan_bakar_awal())
        print('Sisa bahan bakar sekarang = ',bahan_bakar_awal()-jarak_tempuh(jarak)+isi_bahan_bakar(isi))

    elif(pilih==3):
        print('Isi bahan Bakar')
        isi=int(input('Masukkan nomimal bensin yang di isi = '))
        if isi > 1300000 :
            print('Kapasitas Bahan Bakar Penuh')
        else:
            print('bahan bakar yang terisi = ',isi_bahan_bakar(isi),'Liter')

    elif(pilih==4):
        print('Maintenance ke Bengkel')
        jarak+=1
        if jarak > 2 :
            print('Harus ke bengkel')
        else :
            print('Tidak harus ke bengkel')
            Lanjut=True

    elif(pilih==5):
        print('Terimakasih')
        break

    elif(pilih==0):
        break
    

