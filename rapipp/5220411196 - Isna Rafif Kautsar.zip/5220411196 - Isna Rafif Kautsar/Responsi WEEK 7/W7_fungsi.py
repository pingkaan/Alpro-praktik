def jarak_tempuh(km):
    perjalanan=km*3
    return perjalanan

def bahan_bakar_awal():
    bbaw=100
    return bbaw

def bahan_bakar_akhir(bbak):
    bbaw=100
    bahan_bakar_akhir=100-bbak
    return bahan_bakar_akhir

def isi_bahan_bakar(s):
    diisi=s/13000
    return diisi




