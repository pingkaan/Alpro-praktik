#5220411196 - Isna Rafif Kautsar
#connector python to database

#import library mysql.connector
from mysql import connector

#koneksi ke Database mysql
connect = connector.connect(
    host="localhost",
    user="root",
    password="",
    database="praktikum_alpro_sabtu"
)

#buat cursor untuk operasi basis data
cursor = connect.cursor()

# buat tabel mahasiswa dengan skema atribut seperti
# nama kolom || Tipe data || lenght
# nim           : VARCHAR   :   15
# nama          : VARCHAR   :   50
# umur          : INT       :   5
# kelas         : VARCHAR   :   50

#lakukan eksekusi query dgn ssql buat database
cursor.execute(
    "CREATE TABLE mahasiswa(nim VARCHAR(15), nama VARCHAR(50), umur INT(5),kelas VARCHAR(50));"
    )

#tampilkan basis data
cursor.execute("SHOW DATABASES;")

print("tabel di database praktikum_alpro_sabtu : ")
for db in cursor:
    print(db[0])

cursor.close()
connect.close()