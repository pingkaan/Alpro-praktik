#5220411196 - Isna Rafif Kautsar
#connector python to database

#import library mysql.connector
from mysql import connector

#koneksi ke Database mysql
connect = connector.connect(
    host="localhost",
    user="root",
    password=""
)

if connect.is_connected():
    print("Sukses....")