#5220411196 - Isna Rafif Kautsar

from mysql import connector

connect = connector.connect(
    host="localhost",
    user="root",
    password="",
    database="praktikum_alpro_sabtu"
)

cursor = connect.cursor()

cursor.execute(
    """
    CREATE TABLE mahasiswa(nim VARCHAR(15), nama VARCHAR(50), umur INT(5),kelas VARCHAR(50));
    """
    )

cursor.execute("SHOW TABLES;")

print("tabel di database praktikum_alpro_sabtu : ")
for db in cursor:
    print(db[0])

cursor.close()
connect.close()