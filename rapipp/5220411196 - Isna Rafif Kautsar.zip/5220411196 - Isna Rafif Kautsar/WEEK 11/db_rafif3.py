#5220311196 - Isna Rafif Kautsar

import mysql.connector
from fungsi_db import masukkan_data
from fungsi_db import tampilkan_data
from fungsi_db import ubah_data
from fungsi_db import hapus_data

dbs = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="",
    database="dbs_rafif"
)

import os
while True:
    os.system("clear")
    print("=== Aplikasi CRUD database ===")
    print("Pilih Menu ---> ")
    print("1. Masukkan Data")
    print("2. Tampilkan Data")
    print("3. Ubah Data")
    print("4. Hapus Data")
    print("0. Keluar")
    print("==================================")
    
    menu = input("Pilih Menu ---> ")
    if menu == "1":
        masukkan_data(dbs)
    elif menu == "2":
        tampilkan_data(dbs)
    elif menu == "3":
        ubah_data(dbs)
    elif menu == "4":
        hapus_data(dbs)
    else:
        print("Thank You....")
        break
    os.system("pause")