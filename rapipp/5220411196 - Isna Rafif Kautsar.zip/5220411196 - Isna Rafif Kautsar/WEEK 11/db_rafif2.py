#5220411196 - Isna Rafif Kautsar

import mysql.connector

dbs = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="",
    database="dbs_rafif"
)

cursor = dbs.cursor()
sql = """CREATE TABLE daftar_mhs (
    nim VARCHAR(15),
    nama VARCHAR(50),
    umur INT(5)
    )
    """
cursor.execute(sql)

print("Tabel daftar mahasiswa suskses dibuat")