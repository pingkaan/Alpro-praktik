import mysql.connector
import matplotlib.pyplot as plt

db = mysql.connector.connect(
    host = "127.0.0.1",
    user = "root",
    password = "",
    database = "db_mahasiswa"
)

mycursor = db.cursor()

def menampilkan():
    mycursor.execute("SELECT * FROM tb_data")
    result = mycursor.fetchall()
    for i in result:
        print(i)

def menambah():
    sql = "INSERT INTO tb_data (nama,nim) VALUES (%s,%s)"
    data = []
    nama = input("Masukan Nama Anda : ")
    nim = input("Masukan NIM Anda : ")
    data.append(nama)
    data.append(nim)
    mycursor.execute(sql,data)
    db.commit()

def tampilNamaNim():
    mycursor.execute("SELECT * FROM tb_data")
    result = mycursor.fetchall()
    for i in result:
        print(i[1],",",i[2])


def cariNIM():
    mycursor.execute("SELECT * FROM tb_data")
    result = mycursor.fetchall()
    NIM = input("Masukan data NIM Anda : ")
    for i in result:
        if i[1]== NIM:
            print(i)

def grafik():
    mycursor.execute("SELECT * FROM tb_nilai")
    result = mycursor.fetchone()
    mapel = ["bahasa","agama","alpro"]
    print(result)
    plt.bar(mapel,result[1:])
    plt.show()


while True:
    print("1. Insert Data")
    print("2. Tampilkan Semua Data")
    print("3. Tampilkan Nama,NIM")
    print("4. Cari data berdasarkan NIM")
    print("5. pilih grafik")
    print("6. Exit")
    pilih = input("Pilih Menu: ")
    if pilih == "1":
        menambah()
    elif pilih == "2":
        menampilkan()
    elif pilih == "3":
        tampilNamaNim()
    elif pilih == "4":
        cariNIM()
    elif pilih == "5":
        grafik()
    elif pilih == "6":
        exit()
    else:
        ("Data yang anda cari tidak ada!")
