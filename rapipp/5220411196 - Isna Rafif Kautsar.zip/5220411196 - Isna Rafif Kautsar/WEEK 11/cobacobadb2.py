import mysql.connector
import matplotlib.pyplot as plt

db = mysql.connector.connect(
    host = "127.0.0.1",
    password = "",
    user = "root",
    database = "db_kuliah"
)

mycursor = db.cursor()

def inputadmin():
    sql = "INSERT INTO tb_mahasiswa(nim,nama,nilai_alpro,nilai_agama,nilai_tbo) VALUES (%s,%s,%s,%s,%s)"
    data = []
    nim = input("Masukan data NIM anda : ")
    nama = input("Masukan data NAMA anda : ")
    nilaialpro = input("Masukan data Nilai Alpro: ")
    nilaiagama = input("Masukan data Nilai Agama : ")
    nilaitbo = input("Masukan data Nilai TBO : ")
    data.append(nim)
    data.append(nama)
    data.append(nilaialpro)
    data.append(nilaiagama)
    data.append(nilaitbo)
    mycursor.execute(sql,data)
    db.commit

def menampilkan():
    mycursor.execute("SELECT * FROM tb_mahasiswa")
    result = mycursor.fetchall()
    for i in result:
        print("NIM : ",i[1])
        print("NAMA : ",i[2])
        print("Nilai Alpro : ",i[3])
        print("Nilai Agama : ",i[4])
        print("Nilai TBO : ",i[5])

def caridata():
    sql ="SELECT * FROM tb_mahasiswa"
    mycursor.execute(sql)
    result = mycursor.fetchall()
    print("1. Cari Berdasarkan NIM ")
    print("2. Cari Bersarkan Nama")
    pilih = input("Pilih Menu : ")
    if pilih == "1":
        nim = input("Masukan NIM yang Anda cari : ")
        for i in result:
            if i[1] == nim:
                print("NIM : ",i[1])
                print("NAMA : ",i[2])
                print("Nilai Alpro : ",i[3])
                print("Nilai Agama : ",i[4])
                print("Nilai TBO : ",i[5])
                break
            else:
                print("Data tidak ada!")
    if pilih == "2":
        nama = input("Masukan Nama yang Anda cari : ")
        for i in result:
            if i[2] == nama:
                print("NIM : ",i[1])
                print("NAMA : ",i[2])
                print("Nilai Alpro : ",i[3])
                print("Nilai Agama : ",i[4])
                print("Nilai TBO : ",i[5])
                break
            else:
                print("Data tidak ada!")

def admin():
    password = input("Masukan Password anda : ")
    if password != "admin123":
        print("Password Salah !")
        return True
    else:
        while True:
            print("1.Input Data ")
            print("2.Tampil Semua Data")
            print("3.Cari Data")
            print("4.Kembali ke Menu awal")
            pilih = input("Pilih Menu : ")
            if pilih == "1":
                inputadmin()
            elif pilih == "2":
                menampilkan()
            elif pilih == "3":
                caridata()
            elif pilih == "4":
                print("Kembali KeMenu Awal")
                return True

def tampildataMhs():
    sql = "SELECT * FROM tb_mahasiswa"
    mycursor.execute(sql)
    result = mycursor.fetchall()
    nim = input("Masukan NIM yang dicari : ")
    for i in result:
        if i[1] == nim:
            print("NIM : ",i[1])
            print("NAMA : ",i[2])
            print("Nilai Alpro : ",i[3])
            print("Nilai Agama : ",i[4])
            print("Nilai TBO : ",i[5])
            break
        else:
            print("Data Tidak Ada")    

def tampilgrafik():
    mycursor.execute("SELECT * FROM tb_mahasiswa")
    result = mycursor.fetchall()
    nim = input("Masukan NIM : ")
    for i in result:
        if i[1] == nim:
            mycursor.execute("SELECT * FROM tb_matkul")
            data = mycursor.fetchone()
            nama = []
            nama.append(data[1])
            nama.append(data[2])
            nama.append(data[3])
            nilai = i[3:]
            plt.bar(nama,nilai)
            plt.show()
        else:
            print("Data Tidak Ada")

def mahasiswa():
    while True:
        print("1. Lihat Data Berdasarkan NIM")
        print("2. Tampilkan Grafik Nilai")
        print("3. Kembali")
        pilih = input("Pilih Menu : ")
        if pilih == "1":
            tampildataMhs()
        elif pilih == "2":
            tampilgrafik()
        elif pilih == "3":
            print("Kembali")
            return True
        else:
            print("Menu tidak Ada")

while True:
    print("1. Menu Admin")
    print("2. Menu Mahasiswa")
    print("3. Exit")
    pilih = input("Pilih Menu : ")
    if pilih == "1":
        admin()
    elif pilih == "2":
        mahasiswa()
    elif pilih == "3":
        exit()
    else:
        print("Data tidak ditemukan !")