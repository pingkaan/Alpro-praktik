#5220411196 - Isna Rafif Kautsar
#connector python to database

#import library mysql.connector
from mysql import connector

#koneksi ke Database mysql
connect = connector.connect(
    host="localhost",
    user="root",
    password="",
    database="praktikum_alpro_sabtu"
)

#buat cursor untuk operasi basis data
cursor = connect.cursor()

cursor.execute(
    "DELETE FROM mahasiswa WHERE nim = '5220411196';"
    )

connect.commit()

#tampilkan basis data
cursor.execute("SELECT * FROM mahasiswa;")
result = cursor.fetchall()
for data in result:
    print(data[0],'-',data[1],'-',data[2],'-',data[3])

cursor.close()
connect.close()