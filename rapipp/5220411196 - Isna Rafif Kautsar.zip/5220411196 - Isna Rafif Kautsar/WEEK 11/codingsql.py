#5220411196 - Isna Rafif Kautsar

import mysql.connector
from prettytable import from_db_cursor

connect = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="praktikum_alpro_sabtu"
)

def insert_data(connect):
  nim = input("Masukan nim : ")
  nama = input("Masukan nama : ")
  kelas = input("Masukkan kelas : ")
  val = (nama, nim, kelas)
  cursor = connect.cursor()
  sql = "INSERT INTO mahasiswa VALUES(nim, name, kelas);"
  cursor.execute(sql, val)
  connect.commit()
  print("{} data berhasil disimpan".format(cursor.rowcount))


def show_data(connect):
  cursor = connect.cursor()
  sql = "SELECT * FROM mahasiswa"
  cursor.execute(sql)
  results = cursor.fetchall()
  
  if cursor.rowcount < 0:
    print("Tidak ada data")
  else:
    for data in results:
      print(data)


def update_data(db):
  cursor = db.cursor()
  show_data(db)
  customer_id = input("pilih id customer> ")
  name = input("Nama baru: ")
  address = input("Alamat baru: ")

  sql = "UPDATE customers SET name=%s, address=%s WHERE customer_id=%s"
  val = (name, address, customer_id)
  cursor.execute(sql, val)
  db.commit()
  print("{} data berhasil diubah".format(cursor.rowcount))


def delete_data(db):
  cursor = db.cursor()
  show_data(db)
  customer_id = input("pilih id customer> ")
  sql = "DELETE FROM customers WHERE customer_id=%s"
  val = (customer_id,)
  cursor.execute(sql, val)
  db.commit()
  print("{} data berhasil dihapus".format(cursor.rowcount))


def search_data(db):
  cursor = db.cursor()
  keyword = input("Kata kunci: ")
  sql = "SELECT * FROM customers WHERE name LIKE %s OR address LIKE %s"
  val = ("%{}%".format(keyword), "%{}%".format(keyword))
  cursor.execute(sql, val)
  results = cursor.fetchall()
  
  if cursor.rowcount < 0:
    print("Tidak ada data")
  else:
    for data in results:
      print(data)

  #clear screen
import os
while True:
    os.system("cls")
    print('1. Tambah Data')
    print('2. Cetak Data')
    print('3. Mengurutkan data metode Selection')
    print('4. Mengurutkan data metode Bubble')
    print('5. Mencari Data')
    print('6. Hapus data')
    print('0. Selesai')
    pilih=int(input('Pilih Menu     : '))
    if pilih==1:
        insert_data(connect)
    elif pilih==2:
        show_data()
    elif pilih==3:
        update_data()
    elif pilih==4:
        delete_data()
    elif pilih==5:
        search_data()
    elif pilih==6:
        delete_data()
    else:
        print("Terimakasih")
        break
    os.system("pause")