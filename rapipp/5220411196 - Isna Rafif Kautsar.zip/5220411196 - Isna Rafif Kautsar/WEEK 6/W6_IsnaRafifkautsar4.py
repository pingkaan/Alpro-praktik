def pangkat1(x,y):
    pang=1
    for i in range (1,y+1):
        pang=pang*x
    return pang

def pangkat2(x,y):
    if(y==0):
        return 1
    else:
        return (x*pangkat2(x,y-1))

print('Menghitung Pangkat')
a=int(input('Masukkan bilangan yang akan dipangkatkan : '))
b=int(input('dipasangkan pangkat berapa : '))
if(b<0):
    print('pangkat tidak valid')
else:
    print('menggunakan loop')
    print(a,' pangkat ',b,' = ',pangkat1(a,b))
    print('menggunakan recrusive')
    print(a,' pangkat ',b,' = ',pangkat2(a,b))
