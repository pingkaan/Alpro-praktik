def fahrenheit(s):
    return(9/5*s)+32
def reamur(s):
    return(0.8*s)
def kelvin(s):
    return(s+273)
def luas_lingkaran(r):
    phi=22/7
    luas=phi*r*r
    return luas
def keliling_lingkaran(r):
    phi=22/7
    keliling=phi*2*r
    return keliling
def luas_segitiga(depan,samping):
    luas=0.5*depan*samping
    return luas
def keliling_segitiga(depan,samping,miring):
    keliling=depan+samping+miring
    return keliling
def faktorial(x):
    if(x==0):
        return 1
    else:
        return(x*faktorial(x-1))
def pangkat1(x,y):
    if y==0:
        return 1
    else:
        return(x*pangkat1(x,y-1))