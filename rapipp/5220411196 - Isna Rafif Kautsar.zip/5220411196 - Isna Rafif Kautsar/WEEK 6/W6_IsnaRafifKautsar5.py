def faktorial(x):
    if(x==0):
        return 1
    else:
        return(x*faktorial(x-1))

#menghitung permutasi dan kombinasi
print('Menghitung Faktorial, Permutasi dan Kombinasi')
a=int(input('Masukkan bilangan yang difaktorialkan : '))
if(a<0):
    print('Bilangan tidak valid')
else:
    print(a,' faktorial = ',faktorial(a))
print('Permutasi dan kombinasi ')
a=int(input('Masukkan jumlah bilangan : '))
b=int(input('Pengelompokkan bilangan = '))
if(a<b):
    print('Permutasi kombinasi yang tidak bisa dilakukan')
else:
    print('Hasil permutasi dari',a,' dan ',b, ' = ',faktorial(a)/faktorial(a-b))
    print('Hasil permutasi dari',a,' dan ',b, ' = ',faktorial(a)/(faktorial(a-b)*faktorial(b)))
print('Terimakasih')