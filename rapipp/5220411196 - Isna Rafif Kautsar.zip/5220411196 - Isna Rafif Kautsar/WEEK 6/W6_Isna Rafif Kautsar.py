def greeting():
    print('selamat pagi')
    print('hari ini belajar function')
def perkenalan(x,y):
    print('Perkenalkan nama saya :',x,'alamat di :',y)

def hitung_gaji(a,b):
    if(b==1):
        return(a+0.3*a)
    elif(b==2):
        return(a+0.5*a)
    elif(b==3):
        return(a+0.6*a)
    elif(b==4):
        return(a+0.75*a)
    else:
        return(a)

#dipanggil
greeting()
nama=str(input('Siapa nama kamu ? : '))
alamat=str(input('dimana alamat kamu ? : '))
perkenalan(nama,alamat)
gapok=float(input('Berapa gaji pokok kamu : '))
gol=int(input('Pilih golongan 1-4 : '))
print('Nama : ',nama,'Alamat : ',alamat,'Gaji Pokok : Rp ',gapok,'Golongan : ',gol)
print('Gaji bersih Rp ',hitung_gaji(gapok,gol))