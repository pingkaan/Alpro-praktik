from W6_IsnaRafifKautsar3 import fahrenheit
from W6_IsnaRafifKautsar3 import reamur
from W6_IsnaRafifKautsar3 import kelvin

print('Konversi Suhu')
lanjut=True
celsius=float(input('Masukkan suhu dalam celsius : '))
while(lanjut):
    print('Pilih Menu : ')
    print('1. Konversi suhu celsius ke Fahrenheit')
    print('2. Konversi suhu celsius ke Reamur')
    print('3. Konversi suhu celsius ke Kelvin')
    print('0. Selesai')
    pilih=int(input('Pilih menu --> '))
    if(pilih==1):
        print('Suhu dalam celsius = ',celsius,'derajat')
        print('Suhu dalam Fahrenheit = ',fahrenheit(celsius),'derajat')
    elif(pilih==2):
        print('Suhu dalam celsius = ',celsius,'derajat')
        print('Suhu dalam Reamur = ',reamur(celsius),'derajat')
    elif(pilih==3):
        print('Suhu dalam celsius = ',celsius,'derajat')
        print('Suhu dalam Kelvin = ',kelvin(celsius),'derajat')
    elif(pilih==0):
        lanjut=False
        break
    else:
        print('Anda salah memilih menu!')
#after while
print('Terimakasih')