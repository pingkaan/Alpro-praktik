from W6_IsnaRafifKautsar3 import luas_lingkaran
from W6_IsnaRafifKautsar3 import keliling_lingkaran
from W6_IsnaRafifKautsar3 import luas_segitiga
from W6_IsnaRafifKautsar3 import keliling_segitiga
from W6_IsnaRafifKautsar3 import pangkat1
from W6_IsnaRafifKautsar3 import faktorial

print('Tugas Pertemuan 6')
lanjut=True
while(lanjut):
    print('Pilih Menu : ')
    print('1. Menghitung Faktorial')
    print('2. Menghitung luas dan keliling lingkaran')
    print('3. Menghitung pangkat')
    print('4. Menghitung luas dan keliling segitiga siku-siku')
    pilih=int(input('Pilih menu --> '))
    if(pilih==1):
        a=int(input('Masukkan bilangan yang di faktorialkan'))
        print(a,'faktorial = ',faktorial(a))
    elif(pilih==2):
        r=int(input('Masukkan jari-jari lingkaran : '))
        print('Luas lingkaran dengan r atau jari-jari lingkaran : ',r,'adalah : ',luas_lingkaran(r))
        print('keliling lingkaran dengan r atau jari-jari lingkaran',r, 'Adalah : ',keliling_lingkaran(r))
    elif(pilih==3):
        a=int(input('Masukkan bilangan yang ingin dipangkatkan : '))
        b=int(input('Dipasangkan pangkat berapa : '))
        print(a,' pangkat ',b,' = ',pangkat1(a,b))
    elif(pilih==4):
        depan=int(input('Masukkan sisi depan segitiga : '))
        samping=int(input('Masukkan sisi samping segitiga : '))
        miring=int(input('Masukkan sisi miring segitiga : '))
        print('Luas segitiga dengan sisi depan',depan,' dan sisi samping',samping, ' = ',luas_segitiga(depan,samping))
        print('keliling segitiga dengan sisi depan',depan,'sisi samping',samping,'dan sisi miring',miring,' = ',keliling_segitiga(depan,samping,miring))
    elif(pilih==0):
        lanjut=False
        break
    else:
        print('Anda salah memilih menu')
#after while
print('Terimakasih')