#5220411196 Isna Rafif Kautsar
list_angka=[]
list_duplikat=[]
def tambah_data():
    x=int(input('Masukkan Angka Bulat : '))
    list_angka.append(x)
    print('Data sudah ditambahkan')

def cetak_data(L):
    print('Data saat ini')
    for x in list_angka:
        print(x,end=' ')
    print("\n")

def hapus_data():
    cetak_data(list_angka)
    x=int(input('Data mana yang akan dihapus? : '))
    for y in list_angka:
        if y not in list_angka:
            print('Data ',x, 'Tidak ditemukan di list angka ')
        else:
            print('Data ',x,'Ada di list angka ')
            z=str(input('Yakin akan dihapus <y/t> ? : '))
            if z=='y' or z=='Y':
                list_angka.remove(x)
                print('Data sudah dihapus')
            else:
                print('Data tidak jadi dihapus')
                break

def urutkan_data_sel():
    print('Data sebelum diurutkan : ')
    cetak_data(list_angka)
    list_duplikat=list_angka
    x=len(list_duplikat)
    for i in range(0,x-1):
        for j in range(i+1,x-1):
            if list_duplikat[i]>list_duplikat[j]:
                dummy=list_duplikat[i]
                list_duplikat[i]=list_duplikat[j]
                list_duplikat[j]=dummy
    #sudah diurutkan dicetak
    cetak_data(list_duplikat)

def urutkan_data_bub():
    print('Data sebelum diurutkan : ')
    cetak_data(list_angka)
    list_duplikat=list_angka
    x=len(list_duplikat)
    for i in range(0,x-2):
        for j in range(0,(x-1)-i):
            if list_duplikat[j]>list_duplikat[j+1]:
                dummy=list_duplikat[j]
                list_duplikat[j]=list_duplikat[j+1]
                list_duplikat[j+1]=dummy
    #sudah diurutkan dicetak
    cetak_data(list_duplikat)

def cari_data():
    print('Mencari data di list Angka')
    x=int(input('Masukkan data yang akan dicari : '))
    ada=False
    pos=0
    z=len(list_angka)
    for i in range(0,z):
        if list_angka[i]==x:
            ada=True
            pos=i
    if ada:
        print('Data ',x,' Ditemukan di posisi ke ',pos)
    else:
        print('Data ',x,' Tidak Ditemukan ')

import os
while True:
    os.system("cls")
    print('1. Tambah Data')
    print('2. Cetak Data')
    print('3. Mengurutkan data metode Selection')
    print('4. Mengurutkan data metode Bubble')
    print('5. Mencari Data')
    print('6. Hapus data')
    print('0. Selesai')
    pilih=int(input('Pilih Menu     : '))
    if pilih==1:
        tambah_data()
    elif pilih==2:
        cetak_data(list_angka)
    elif pilih==3:
        urutkan_data_sel()
    elif pilih==4:
        urutkan_data_bub()
    elif pilih==5:
        cari_data()
    elif pilih==6:
        hapus_data()
    else:
        print("Terimakasih")
        break
    os.system("pause")