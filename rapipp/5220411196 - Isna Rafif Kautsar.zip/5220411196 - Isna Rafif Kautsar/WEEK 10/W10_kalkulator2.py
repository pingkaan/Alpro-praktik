#5220411196 Isna Rafif Kautsar

from W10_kalkulator import tambah
from W10_kalkulator import kurang
from W10_kalkulator import bagi
from W10_kalkulator import kali
from W10_kalkulator import pangkat
from W10_kalkulator import math

lanjut=True
while(lanjut):
    print('1. Penjumlahan')
    print('2. Pengurangan')
    print('3. Pembagian')
    print('4. Perkalian')
    print('5. Perpangkatan')
    print('6. Perakaran')
    print('0. Selesai')
    pilih=int(input('Pilih Menu -->  '))
    if pilih==1:
        tambah()
    elif pilih==2:
        kurang()
    elif pilih==3:
        bagi()
    elif pilih==4:
        kali()
    elif pilih==5:
        pangkat()
    elif pilih==6:
        a=int(input("Masukkan bilangan yang akan di akarkan : "))
        print("Hasil : ",math.sqrt(bilangan1,bilangan2))
    elif pilih==0:
        print("selesai")
    else:
        print("error")
        break