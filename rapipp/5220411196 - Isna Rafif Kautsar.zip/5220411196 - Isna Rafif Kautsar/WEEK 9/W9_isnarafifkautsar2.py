#5220411196 - Isna Rafif Kautsar
#Dictionary

buku=dict(
    judul= " ",
    penulis= " ",
    harga= "",
    jumlah= " "
)
def isidata(w,x,y,z):
    print("Judul Buku       : ",w)
    print("Penulis          : ",x)
    print("Harga Buku       : Rp.",y)
    print("Jumlah Halaman   : ",z)

while True:
    print("1. Isi Data Buku")
    print("2. Cetak Buku")
    print("3. Ubah Judul Buku")
    print("4. Hapus Buku")
    print("0. Keluar")
    pilihan_menu=int(input("Pilih Menu : "))
    if pilihan_menu==1:
        print('Isi Data Buku')
        judul=input("Masukkan Judul Buku        : ")
        penulis=input("Masukkan Penulis Buku    : ")
        harga=int(input("Masukkan Harga Buku    : "))
        jumlah=int(input("Masukkan Halaman Buku : "))

    if pilihan_menu==2:
        print("Cetak Buku")
        isidata(judul,penulis,harga,jumlah)

    if pilihan_menu==3:
        print("Ubah Judul Buku")
        w=str(input("Masukkan Judul Buku Terbaru : "))
        buku['judul']=w
        print("Judul Buku           : ",buku.get("judul"))
        print("Penulis              : ",buku.get("penulis"))
        print("Harga Buku           : ",buku.get("harga"))
        print("Jumlah Halaman Buku  : ",buku.get("jumlah"))