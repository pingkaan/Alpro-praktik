#5220411196 - Isna Rafif Kautsar
#Dictionary

buku= {
    "judul": "Menu masakan enak",
    "penulis": "Rudy Hartono",
    "harga":50000
}
print('Judul buku   : ',buku.get("judul"))
print('Penulis      : ',buku.get("penulis"))
print('Harga        : Rp.',buku.get("harga"))

buku=dict(
    judul= "Algoritma Pemrograman",
    penulis="Insap Santoso",
    harga=75000
)

#cetak
print('Judul Buku   : ',buku.get("judul"))
print('Penulis      : ',buku.get("penulis"))
print('Harga        : Rp.',buku.get("harga"))

#edit data pada dictionary
x=str(input("Masukkan penulis Algoritma Pemrograman yang baru :  "))
buku['penulis']=x
print('Judul buku   : ',buku.get("judul"))
print('Penulis      : ',buku.get("penulis"))
print('Harga Buku   : Rp.',buku.get("harga"))

#menambah item baru
x=int(input("Masukkan jumlah halaman buku : "))
buku['jumlah']=x
print('Judul buku   : ',buku.get("judul"))
print('Penulis      : ',buku.get("penulis"))
print('Harga Buku   : Rp.',buku.get("harga"))
print('Jumlah Halaman  : ',buku.get("jumlah"))