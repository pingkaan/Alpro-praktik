#5220411196 Isna Rafif Kautsar
from codecs import namereplace_errors

print("Hellow World, saya belajar phyton")
print("Di praktikum Alpro Kelas VI")

#input
nama=str(input("Siapa nama kamu = "))
umur=int(input("masukkan umur kamu = "))
job=str(input("pekerjaan saya adala = ")) 
gaji=float(input("masukkan gaji kamu = "))
dream=str(input("cita cita saya = "))
hobi=str(input("hobi saya = "))



#hasil
print("nama saya", nama, "umur saya", umur, "pekerjaan saya", job, "gaji saya", gaji)
print("cita cita saya", dream, "hobi saya adalah", hobi)