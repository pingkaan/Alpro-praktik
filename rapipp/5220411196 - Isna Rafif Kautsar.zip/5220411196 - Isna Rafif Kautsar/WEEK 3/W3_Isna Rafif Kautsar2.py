#5220411196 Isna Rafif Kautsar

from ast import operator
from re import X

#operator aritmatika
print(input("mengaji operator aritmatika dan assigment"))
a=int(input("masukkan bilangan bulat (a) = "))
b=int(input("masukkan bilangan bulat (b) = "))
print("a+b = ", a+b); print("a-b = ", a-b)
print("a*b = ", a*b); print("a/b = ", a/b)
print("a mod b = ", a%b); print("a div b = ", a//b)
print("a pangkat b", a**b)

#operator assigment
a=int(input("masukkan bilangan bulat (a)"))
print("nilai a = ", a)
a+=5;print("nilai a = ", a)
a-=3;print("nilai a = ", a)
a*=3;print("nilai a = ", a)
a/=2;print("nilai a = ", a)
a//=3;print("nilai a = ", a)
a%=4;print("nilai a = ", a)

#konversi
a=50
print("a= ",a,"dalam biner = ",bin(a))
print("a= ",a,"dalam hexa = ",hex(a))
print("a= ",a,"dalam oktal = ",oct(a))
x=False; print("nilai x = ",x)
x=not(x); print("nilai x = ", x)


