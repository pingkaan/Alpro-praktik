#5220411196 Isna Rafif Kautsar

print("Mencari luas dan keliling Lingkaran")
phi=22/7
r=int(input("masukkan jari-jari lingkaran = "))
L=phi*r*r; K=2*phi*r
print("Luas Lingkaran dengan jari-jari",r, "adalah = ",L, "cm2" )
print("Keliling Lingkaran tsb = ",K, "cm")