#5220411196 Isna Rafif Kautsar

#algoritma hitung luas persegi

print("menghitung Luas Persegi Panjang dan Luas Setengah Lingkaran")

#menghitung luas persegi panjang
p=int(input("masukkan nilai panjang (p)"))
l=int(input("masukkan nilai lebar (l)"))
LP=p*l
print("Luas Persegi panjang = ",LP, "cm^2")

#menghitung luas setengah lingkaran
d=int(input("masukkan nilai diameter (d)"))
phi=22/7
LS=(1/2)*((1/4)*phi*d*d)
print("Luas Setengah Lingkaran",LS, "cm^2")

#Total Luas
print("Luas Persegi Panjang ditambah Luas Setenga Lingkaran")
LT=LP+LS
print("Luas Total Persegi Panjang dan Setengah Lingkaran",LS, "cm^2")
