#5220411196 - Isna Rafif Kautsar
#segitiga bilangan

print('segitiga bilangan ganjil dan genap')
b=int(input('berapa baris bilangan yang akan dicetak ? '))

for i in range(1,b+1):
    a=1
    for j in range(1,i+1):
        print(a,'  ',end=' ')
        a+=2
    print()
#segitiga genap
for i in range(b,0,-1):
    a=2
    for j in range(1,i+1):
        print(a,'  ',end=' ')
        a+=2
    print()