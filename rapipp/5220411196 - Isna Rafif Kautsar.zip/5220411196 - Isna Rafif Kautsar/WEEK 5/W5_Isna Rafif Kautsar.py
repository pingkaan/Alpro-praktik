#5220411196 - Isna Rafif Kautsar

from re import I


print('pengulangan loop FOR')
print('mencetak bilangan dari a dan b')
a=int(input('masukkan awal loop :  '))
b=int(input('masukkan akhir loop :  '))
sum=0;n=0
for i in range(a,b+1):
    if(i==0):
        continue
    if(i%2==0):
        print(i,'  ',end='  ')
        sum+=i
        n+=1
else:
    for i in range(a,b-1,-1):
        if(i==0):
            continue
        if(i%2==0):
            print(i,'  ',end=' ')
            sum+=i
            n+=1

#after loop
if(n>0):
    print('\nanda mencetak',n,'buah bilangan genap')
    print('Jumlah bilangan tsb',sum)
    print('Rata-ratanya',sum/n)
else:
    print('Tidak ada bilangan genap yang dicetak')
