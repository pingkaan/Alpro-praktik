#5220411196 - Isna Rafif Kautsar
#menu

from psutil import pid_exists


print('Memilih menu Python')
print('==========================')
print('Program Konversi Suhu')
print('Menu Pilihan')
print('==========================')
lanjut=True
while(lanjut):
    print('Pilih Menu : ')
    print('1. Konversi Celcius ke Fahrenheit')
    print('2. Konversi Fahrenheit ke Celcius')
    print('3. Konversi Celcius ke Kelvin')
    print('4. Konversi Kelvin ke Celcius')
    print('0. selesai')
    pilih=int(input('Pilih menu --> '))
    if(pilih==1):
        C=float(input('Masukkan Jumlah suhu ruangan dalam C : '))
        F=((C*9/5)+32)
        print('Hasil Konversi adalah F = ',F)
    elif(pilih==2):
        F=float(input('Masukkan jumlah suhu ruangan dalam F : '))
        C=((F-32)*5/9)
        print('Hasil Konversi adalah C = ',C)
    elif(pilih==3):
        C=float(input('masukkan jumlah suhu ruangan dalam C : '))
        K=(C+273.15)
        print('Hasil Konversi adalah K = ',K)
    elif(pilih==4):
        K=float(input('masukkan jumlah suhu ruangan dalam K : '))
        C=(K-273.15)
        print('Hasil Konversi adalah C = ',C)
    elif(pilih==0):
        lanjut=False
        break
    else:
        print('Anda salah memilih menu')
#after while
print('=================================')
print('Arigatou Gozaimas')