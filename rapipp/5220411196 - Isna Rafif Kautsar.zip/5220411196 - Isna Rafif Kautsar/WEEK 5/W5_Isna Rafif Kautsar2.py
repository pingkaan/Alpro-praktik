#5220411196 - Isna Rafif Kautsar
#while loop
from operator import truediv


print('input sejumlah bilangan genap, dipilih ganjil dan genap')
n1=0;n2=0;sum1=0;sum2=0
lanjut=True
while(lanjut):
    angka=int(input('Masukkan bilangan bulat <isi nol untuk berhenti> : '))
    if(angka==0):
        lanjut=False
        break
    if(angka%2==0):
        n2+=1
        sum2+=angka
    else:
        n1+=1
        sum1+=angka
else:
    print('inputan selesai')

#after loop
print('anda mnginputkan',n1+n2,'buah bilangan')
print('anda mendapatkan bilangan genap',n2,'buah, jumlah',sum2)
print('bilangan ganjil',n1,'buah,jumlah',sum1)