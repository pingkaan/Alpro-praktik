-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 14, 2023 at 04:03 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tegar_rakasiwi`
--

-- --------------------------------------------------------

--
-- Table structure for table `5220411203_tegar_rakasiwi`
--

CREATE TABLE `5220411203_tegar_rakasiwi` (
  `no_pendaftaran` int(11) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `kode_kursus` varchar(30) NOT NULL,
  `biaya` decimal(11,0) NOT NULL,
  `status_bayar` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `5220411203_tegar_rakasiwi`
--

INSERT INTO `5220411203_tegar_rakasiwi` (`no_pendaftaran`, `nama`, `kode_kursus`, `biaya`, `status_bayar`) VALUES
(9, 'Tegar Rakasiwi', '123', '2000000', 'Lunas'),
(10, 'Tegar', '456', '1500000', 'Belum Lunas'),
(12, 'ABC', '456', '1500000', 'Lunas');

-- --------------------------------------------------------

--
-- Table structure for table `jenis_kursus`
--

CREATE TABLE `jenis_kursus` (
  `kode_kursus` varchar(5) NOT NULL,
  `nama_kursus` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jenis_kursus`
--

INSERT INTO `jenis_kursus` (`kode_kursus`, `nama_kursus`) VALUES
('123', 'Data Scientist'),
('456', 'Software Development'),
('789', 'Web Development');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `5220411203_tegar_rakasiwi`
--
ALTER TABLE `5220411203_tegar_rakasiwi`
  ADD PRIMARY KEY (`no_pendaftaran`),
  ADD KEY `jenis_kursus` (`kode_kursus`);

--
-- Indexes for table `jenis_kursus`
--
ALTER TABLE `jenis_kursus`
  ADD PRIMARY KEY (`kode_kursus`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `5220411203_tegar_rakasiwi`
--
ALTER TABLE `5220411203_tegar_rakasiwi`
  MODIFY `no_pendaftaran` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `5220411203_tegar_rakasiwi`
--
ALTER TABLE `5220411203_tegar_rakasiwi`
  ADD CONSTRAINT `5220411203_tegar_rakasiwi_ibfk_1` FOREIGN KEY (`kode_kursus`) REFERENCES `jenis_kursus` (`kode_kursus`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
