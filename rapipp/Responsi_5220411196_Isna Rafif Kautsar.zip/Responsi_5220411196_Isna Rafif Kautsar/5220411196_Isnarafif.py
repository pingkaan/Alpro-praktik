#522041196 - Isna RAfif Kautsar

from connect import *
from prettytable import from_db_cursor
import os

#Fungsi
def lihat_kursus():
    mycursor.execute("SELECT * FROM jenis_kursus")
    p = from_db_cursor(mycursor)
    print(p)

def insert_pendaftaran():
    sql = "INSERT INTO isna_rafif(no_pendaftaran,nama, kode_kursus,biaya,status_bayar) VALUES ('',%s,%s,%s,'Belum Lunas')"
    val = (nama,jenis_kursus,biaya)
    mycursor.execute(sql,val)
    mydb.commit()

def lihat_data_pendaftar():
    sql = "SELECT * FROM isna_rafif"
    mycursor.execute(sql)
    p = from_db_cursor(mycursor)
    print(p)

def tagihan():
    sql = "SELECT biaya FROM isna_rafif WHERE no_pendaftaran = %s"
    val = (no_pendaftaran,)
    mycursor.execute(sql,val)
    myresult = mycursor.fetchall()
    for x in myresult:
        values = ','.join(str(v) for v in x)
        to_int = int(values)
        return to_int

def pembayaran():
    sql = "UPDATE isna_rafif SET status_bayar = 'Lunas' WHERE no_pendaftaran = %s"
    val = (no_pendaftaran,)
    mycursor.execute(sql,val)
    mydb.commit()

def cari():
    sql = "SELECT * FROM isna_rafif WHERE no_pendaftaran = %s"
    val = (no_pendaftaran,)
    mycursor.execute(sql,val)
    p = from_db_cursor(mycursor)
    print(p)

def batal():
    sql = "DELETE FROM isna_rafif WHERE no_pendaftaran = %s"
    val = (no_pendaftaran,)
    mycursor.execute(sql,val)
    mydb.commit()


lanjut = True
while lanjut :
    os.system('cls')
    print("============================")
    print("Pendaftaran Kursus")
    print("============================")
    print("Daftar Menu")
    print("="*20)
    print("1. Pendaftaran Kursus")
    print("2. Lihat Data Kursus")
    print("3. Pembayaran")
    print("4. Cari Data Pendaftar")
    print("5. Batalkan Pendaftaran")
    print("0. Keluar")
    print("="*20)
    pilih = int(input("Masukkan Pilihan Anda : "))
    if pilih == 1:
        os.system('cls')
        print("Pendaftaran Kursus")
        print("="*20)
        lihat_kursus()
        nama =          input("Masukkan Nama Peserta         : ")
        jenis_kursus =  input("Masukkan Jenis Kursus         : ")
        if jenis_kursus == '123':
            biaya = 2000000
        elif jenis_kursus == '456':
            biaya = 1500000
        elif jenis_kursus == '789':
            biaya = 1250000
        else:
            print("Kesalahan Data")
        lanjut_daftar = input("Lanjutkan Pendaftaran [Y/T]   : ")
        if lanjut_daftar == 'Y' or lanjut_daftar == 'y':
            insert_pendaftaran()
            print(mycursor.rowcount," data, Berhasil ditambahkan")
            os.system('pause')
        elif lanjut_daftar == 'T' or lanjut_daftar == 't':
            print("Pendaftaran di Cancel")
            os.system('pause')

    elif pilih == 2:
        os.system('cls')
        print("Lihat Data Pendaftar")
        print("="*25)
        lihat_data_pendaftar()
        os.system("pause")

    elif pilih == 3:
        os.system('cls')
        print("Pembayaran")
        print("="*25)
        no_pendaftaran = input("Masukkan Nomer Pendaftaran Anda     : ")
        bill = tagihan()
        print("Tagihan Anda                        : Rp.", bill)
        lanjut_bayar = input("Lanjutkan Pembayaran [Y/T]          : ")
        if lanjut_bayar == 'Y' or lanjut_bayar == 'y':
            os.system('cls')
            print("Tagihan Anda                        : Rp.", bill)
            uang = int(input("Masukkan Uang Anda                  : Rp. "))
            if uang > bill:
                kembalian = uang - bill
                print       ("Kembalian Anda                      : Rp.",kembalian)
                pembayaran()
            elif uang < bill:
                print('Uang Anda Kurang')
            else:
                print('Uang Anda Pas')
                pembayaran()
            os.system('pause')
        if lanjut_bayar == 'T' or lanjut_bayar == 't':
            os.system('cls')
            print("Pembayaran Di Cancel")
            os.system('pause')

    elif pilih == 4:
        os.system('cls')
        print("Cari Data Pendaftar")
        print("="*25)
        no_pendaftaran = input("Masukkan Nomer Pendaftaran : ")
        cari()
        os.system('pause')
            
    elif pilih == 5:
        os.system('cls')
        print("Batalkan Pendaftaran")
        print("="*25)
        no_pendaftaran = input("Masukkan Nomer Pendaftaran Anda : ")
        print("Data yang akan di Batalkan")
        cari()
        lanjut_batal =   input("Lanjutkan Pembatalan [Y/T]      : ")
        if lanjut_batal == 'Y' or lanjut_batal == 'y':
            print(mycursor.rowcount," Data, Berhasil Dihapus")
            batal()
            os.system('pause')
        elif lanjut_batal == 'T' or lanjut_batal == 't':
            print("Pembatalan di Cancel")
            os.system('pause')


    elif pilih == 0:
        lanjut = False
        break

    else:
        print("Kode Salah")
        os.system('pause')

print("="*30)
print("Terimakasih telah mendaftar kursus disini ^_^ ")
print("="*30)