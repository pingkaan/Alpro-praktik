from mysql import connector

mydb = connector.connect(
    host = "localhost",
    user = "root",
    password = "",
    database = "isna_rafif_kautsar"
)

mycursor = mydb.cursor()

