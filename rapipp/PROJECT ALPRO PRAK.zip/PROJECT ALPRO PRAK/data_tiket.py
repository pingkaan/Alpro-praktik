import mysql.connector
from csv import DictWriter
from csv import DictReader
import os

conn = mysql.connector.connect(host='localhost', username='root',password='', database='Tiket_Kereta')
my_cursor = conn.cursor()

print("\n******************** SELAMAT DATANG DI PEMESANAN TIKET KERETA ***********************")

acc = input("\nAPAKAH KAMU PUNYA AKUN? (Y/N)")
e = []
if acc=='y' or acc=='yes' or acc=='Y' or acc=='YES':
    email = input("\nMASUKKAN EMAIL KAMU :-")
    e.append(email)
    pas = input("\nMASUKKAN PASSWORD :-")
    otp = int(input("\nMASUKKAN KODE OTP DI EMAIL ATAU NOMOR HP :-"))
   
    print("\n------- LOGIN SUKSES -------")

else:
    nam = input("\nMASUKKAN NAMA KAMU :-")
    pn = int(input("\nMASUKKAN NOMOR HP :-"))
    city = input("\nMASUKKAN ASAL KOTA :-")
    state = input("\nMASUKKAN ASAL NEGARA :-")
    em = input("\nMASUKKAN EMAIL ANDA :-")
    e.append(em)
    passw = input("\nMASUKKAN PASSWORD :-")
    print(f"\nOTP DIKIRIM KE {pn} AND {em}")
    ot = int(input("\nMASUKKAN KODE OTP :-"))
    
    print("\n------- YOUR ACCOUNT IS CREATED SUCCESSFULLY -------")


print("\nBagaimana Anda ingin mencari perjalanan Anda")
print("1.nomor kereta")
print("2.manual")

ans = int(input("\nJawaban (1/2):-"))


if ans==1:
    num = (input("\nMASUKKAN NOMOR TIKET :-"))
    query = "SELECT * FROM kereta_api WHERE nomor_tiket = '{}' ".format(num)
    my_cursor.execute(query)
    print("\nDATA PERJALANANMU ADALAH -------")
    for a in my_cursor:
        print(a)

deplo = []
arrlo = []
fli = []

def flight_data():   
    keberangkatan = input("\nMASUKKAN LOKASI KEBERANGKATAN ANDA :-")
    tujuan = input("\nMASUKKAN LOKASI ANDA TIBA :-")
    query2 = "SELECT daftar_kereta FROM kereta_api WHERE keberangkatan = '{}' AND tujuan = '{}'".format(keberangkatan, tujuan)
    deplo.append(keberangkatan)
    arrlo.append(tujuan)
    my_cursor.execute(query2)
    print("\nPERJALANAN WAJIB ANDA ADALAH ------")
    for b in my_cursor:
        print(b) 
    fly = input("\nMASUKKAN DAFTAR KERETA YANG ANDA INGINKAN :-")
    fli.append(fly)
    print("\nMENDENGAR DETAIL PERJALANAN ANDA --")
    query3 = "SELECT * FROM kereta_api WHERE daftar_kereta = '{}' AND keberangkatan = '{}' AND tujuan = '{}' ".format(fly, keberangkatan, tujuan)
    my_cursor.execute(query3)
    for c in my_cursor:
        return print(c)
        
        

if ans==2:
    flight_data()
    

con = input("\nAPAKAH ANDA INGIN MELANJUTKAN? (Y/N):-")
while True:
    if con=='n' or con=='N' or con=='no' or con=='NO':
        flight_data()
    else:
        break

passenger = int(input("\nMASUKKAN JUMLAH PENUMPANG :-"))

nam=[]
ag=[]
gen=[]

def pass_data():
    name = input("\nMASUKKAN NAMA PENUMPANG :-")
    age = int(input(f"\nMASUKKAN UMUR DARI {name}:-"))
    gender = input("\nMALE/FEMALE :-")
    nam.append(name)
    ag.append(age)
    gen.append(gender)
    with open('userdata.csv', 'a', newline='') as csvfile:
        csvwriter = DictWriter(csvfile, fieldnames=['nama', 'umur', 'jenis kelamin'])
        csvwriter.writeheader()
        csvwriter.writerow({'nama':name, 'umur':age, 'jenis kelamin':gender})
    return print("\n------- DATA ENTERED SUCCESSFULLY -------")        

for d in range(passenger):
        pass_data()

def read_csv():
    with open('userdata.csv') as csvreader:
        reader = DictReader(csvreader)
        for row in reader:
            print(row)
    os.remove(r'userdata.csv')
    return print("------------------------------------")
read_csv()
print("\nCHECK DETAIL DATA ANDA ----")

ch = input("\nAPAKAH ANDA INGIN MELANJUTKAN? (Y/N):-")

while True:
    if ch=='n' or ch=='N' or ch=='no' or ch=='NO':
        for e in range(passenger):
            pass_data()
        read_csv()
    else:
        break

print("\nPILIH CLASS YANG ANDA INGINKAN :-")
print("1.ECONOMY CLASS")
print("2.EXECUTIVE CLASS (+20% BIAYA)")
print("3.PREMIUM CLASS (+40% BIAYA)")

flo = []
tdep = []
tarr= []

def fl_nm():
    query4 = "SELECT nomor_tiket FROM kereta_api WHERE daftar_kereta = '{}' and keberangkatan = '{}' and tujuan = '{}' ".format (fli[0], deplo[0], arrlo[0])
    my_cursor.execute(query4)
    for f in my_cursor:
        flo.append(f)

    query5 = "SELECT waktu_keberangkatan FROM kereta_api WHERE daftar_api = '{}' and keberangkatan = '{}' and tujuan = '{}' ".format (fli[0], deplo[0], arrlo[0])
    my_cursor.execute(query5)
    for g in my_cursor:
        tdep.append(g)

    query6 = "SELECT waktu_sampai FROM kereta_api WHERE daftar_kereta = '{}' and keberangkatan = '{}' and tujuan = '{}' ".format (fli[0], deplo[0], arrlo[0])
    my_cursor.execute(query6)
    for h in my_cursor:
        tarr.append(h)

an = []
de = []
ds = []
td = []
ta = []

def fl_no():
    query7 = "SELECT daftar_kereta FROM kereta_api WHERE nomor_tiket = '{}'".format(num)
    my_cursor.execute(query7)
    for i in my_cursor:
        an.append(i)

    query8 = "SELECT keberangkatan FROM kereta_api WHERE nomor_tiket = '{}'".format(num)
    my_cursor.execute(query8)
    for j in my_cursor:
        de.append(j)

    query9 = "SELECT tujuan FROM kereta_api WHERE nomor_tiket = '{}'".format(num)
    my_cursor.execute(query9)
    for k in my_cursor:
        ds.append(k) 

    query10 = "SELECT waktu_keberangkatan FROM kereta_api WHERE nomor_tiket = '{}'".format(num)
    my_cursor.execute(query10)
    for l in my_cursor:
        td.append(l)

    query11 = "SELECT waktu_sampai FROM kereta_api WHERE nomor_tiket = '{}'".format(num)
    my_cursor.execute(query11)
    for m in my_cursor:
        ta.append(m)

cl = int(input("\nMASUKKAN NOMOR KELAS (1/2/3):-"))

payment = []

if ans==1 and cl==1:
    fl_no()
    query12 = "SELECT biaya*{} FROM kereta_api WHERE nomor_tiket = '{}'".format(passenger, num)
    print(f"\nnama = {nam}               umur = {ag}           jenis kelamin = {gen}")
    print(f"nama kereta = {an}         keberangkatan = {de}       tujuan = {ds}")
    print(f"nomor tiket = {num}      waktu keberangkatan = {td}        waktu sampai = {ta}     ")
    print("class = economy class")
    for n in my_cursor:
        payment.append(n)
        print(f"\nKAMU HARUS MEMBAYAR {n} RUPIAH")

elif ans==1 and cl==2:
    fl_no()
    query13 = "SELECT (biaya +biaya*0.2)*{} FROM kereta_api WHERE nomor_tiket = '{}' ".format (passenger, num)
    my_cursor.execute(query13)
    print(f"\nnama = {nam}               umur = {ag}           jenis kelamin = {gen}")
    print(f"nama kereta = {an}         keberangkatan = {de}       tujuan = {ds}")
    print(f"nomor tiket = {num}      waktu keberangkatan = {td}        waktu sampai = {ta}     ")
    print("class = executive class")
    for o in my_cursor:
        payment.append(o)
        print(f"\nKAMU HARUS MEMBAYAR {o} RUPIAH") 

elif ans==1 and cl==3:
    fl_no()
    query14 = "SELECT (biaya +biaya*0.4)*{} FROM kereta_api WHERE nomor_tiket = '{}'".format (passenger, num)
    my_cursor.execute(query14)
    print(f"\nnama = {nam}               umur = {ag}           jenis kelamin = {gen}")
    print(f"nama kereta = {an}         keberangkatan = {de}       tujuan = {de}")
    print(f"nomor tiket = {num}      waktu keberangkatan = {td}        waktu sampai = {ta}     ")
    print("class = premium class")
    for p in my_cursor:
        payment.append(p)
        print(f"\nKAMU HARUS MEMBAYAR {p} RUPIAH")


elif ans==2 and cl==1:
    fl_nm()
    query15 = "SELECT biaya*{} FROM kereta_api WHERE daftar_kereta = '{}' and keberangkatan = '{}' and tujuan = '{}' ".format (passenger, fli[0], deplo[0], arrlo[0])
    my_cursor.execute(query15)
    print(f"\nnama = {nam}               umur = {ag}           jenis kelamin = {gen}")
    print(f"nama kereta = {fli}         keberangkatan = {deplo}       tujuan = {arrlo}")
    print(f"nomor tiket = {flo}      waktu keberangkatan = {tdep}        waktu sampai = {tarr}     ")
    print("class = economy class")
    for q in my_cursor:
        payment.append(q)
        print(f"\nKAMU HARUS MEMBAYAR {q} RUPIAH") 

elif  ans==2 and cl==2:
    fl_nm()
    query16 = "SELECT (biaya +biaya*0.2)*{} FROM kereta_api WHERE daftar_kereta = '{}' and keberangkatan = '{}' and tujuan = '{}' ".format (passenger, fli[0], deplo[0], arrlo[0])
    my_cursor.execute(query16)
    print(f"\nnama = {nam}               umur = {ag}           jenis kelamin = {gen}")
    print(f"nama kereta = {fli}         keberangkatan = {deplo}       tujuan = {arrlo}")
    print(f"nomor tiket = {flo}      waktu keberangkatan = {tdep}        waktu sampai = {tarr}     ")
    print("class = executive class")
    for r in my_cursor:
        payment.append(r)
        print(f"\nKAMU HARUS MEMBAYAR {r} RUPIAH")  

elif ans==2 and cl==3:
    fl_nm()
    query17 = "SELECT (biaya +biaya*0.4)*{} FROM kereta_api WHERE daftar_kereta = '{}' and keberangkatan = '{}' and tujuan = '{}' ".format (passenger, fli[0], deplo[0], arrlo[0])
    my_cursor.execute(query17)
    print(f"\nnama = {nam}               umur = {ag}           jenis kelamin = {gen}")
    print(f"nama kereta = {fli}         keberangkatan = {deplo}       tujuan = {arrlo}")
    print(f"nomor tiket = {flo}      waktu keberangkatan = {tdep}        waktu sampai = {tarr}     ")
    print("class = premium class")
    for s in my_cursor:
        payment.append(s)
        print(f"\nKAMU HARUS MEMBAYAR {s} RUPIAH")

pay = input("\nUNTUK MEMBAYAR TEKAN (P):-")

if pay=='p' or pay=='P':
    print("\nINGIN METODE PEMBAYARAN APA ?")
    print("1.GOOGLE PAY")
    print("2.QRIZZ PAY")
    print("3.OVO")
    print("4.DANA")
    print("5.CREDIT CARD")
    print("6.DEBIT CARD")
    print("7.BANK TRANSFER")

pay2 = int(input("\nMASUKKAN METODE PEMBAYARAN (1/2/3/4........):-"))

if pay2==1:
    print("\n------------------- GOOGLE PAY ---------------------------")
    print(F"BAYAR {payment[0]} RUPIAH")
    pay3 = input("\nUNTUK MELANJUTKAN TEKAN (P):-")
    ott = int(input("\nMASUKKAN KODE OTP YANG DIKIRIM KE NOMOR HP ATAU EMAIL ANDA :-"))
    print("\nTRANSAKSI BERHASIL ------------")
    print("\n********** TERIMA KASIH ***********")

if pay2==2:
    print("\n------------------- QRIZZ PAY ---------------------------")
    print(F"BAYAR {payment[0]} RUPIAH")
    pay3 = input("\nUNTUK MELANJUTKAN TEKAN (P):-")
    ott = int(input("\nMASUKKAN KODE OTP YANG DIKIRIM KE NOMOR HP ATAU EMAIL ANDA :-"))
    print("\nTRANSAKSI BERHASIL ------------")
    print("\n********** TERIMA KASIH ***********")
    
if pay2==3:
    print("\n------------------- OVO ---------------------------")
    print(F"BAYAR {payment[0]} RUPIAH")
    pay3 = input("\nUNTUK MELANJUTKAN TEKAN (P):-")
    ott = int(input("\nMASUKKAN KODE OTP YANG DIKIRIM KE NOMOR HP ATAU EMAIL ANDA :-"))
    print("\nTRANSAKSI BERHASIL ------------")
    print("********** TERIMA KASIH ***********")

if pay2==4:
    print("\n------------------- DANA ---------------------------")
    print(F"BAYAR {payment[0]} RUPIAH")
    pay3 = input("\nUNTUK MELANJUTKAN TEKAN (P):-")
    ott = int(input("\nMASUKKAN KODE OTP YANG DIKIRIM KE NOMOR HP ATAU EMAIL ANDA :-"))
    print("\nTRANSAKSI BERHASIL ------------")
    print("********** TERIMA KASIH ***********")

if pay2==5 or pay2==6:
    print("\n------------------- CARD payment ---------------------------")
    print(F"BAYAR {payment[0]} RUPIAH")
    c_no = int(input("\nMASUKKAN NOMOR KARTU ANDA :-"))
    cvv = int(input("\nMASUKKAN CVV KARTU ANDA :-"))
    ott2 = int(input("\nMASUKKAN KODE OTP YANG DIKIRIM KE NOMOR ANDA :-"))
    print("\nTRANSAKSI BERHASIL ------------")
    print("********** TERIMA KASIH ***********")

print("\n-------- TERIMA KASIH TELAH MENGGUNAKAN SISTEM BOOKING TIKET KAMI --------------")
print(f"\nTIKET ANDA AKAN DIKIRIM KE EMAIL ANDA {e[0]} ")
print("\nSAMPAI JUMPA LAGI :)")



conn.close()
