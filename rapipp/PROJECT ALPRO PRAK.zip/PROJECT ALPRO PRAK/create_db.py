from mysql import connector

connect = connector.connect(
    host = "localhost",
    user = "root",
    password = ""
)

cursor = connect.cursor()

cursor.execute("CREATE DATABASE Tiket_Kereta;")

cursor.execute("SHOW DATABASES;")

for db in cursor:
    print(db[0])
    
cursor.close()
connect.close()