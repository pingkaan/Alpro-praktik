from mysql import connector

connect = connector.connect(
    host = "localhost",
    user = "root",
    password = ""
)

if connect.is_connected():
    print("sukses")
