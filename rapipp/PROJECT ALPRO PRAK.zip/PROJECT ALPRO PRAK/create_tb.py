from mysql import connector

connect = connector.connect(
    host = "localhost",
    user = "root",
    password = "",
    database = "Tiket_Kereta"
)

cursor = connect.cursor()

cursor.execute(
    """
    CREATE TABLE kereta_api(daftar_kereta VARCHAR(100), keberangkatan VARCHAR(100), tujuan VARCHAR(100), nomor_tiket VARCHAR(50), waktu_keberangkatan VARCHAR(50), waktu_sampai VARCHAR(50), biaya INT );
    """
)

cursor.execute("SHOW TABLES;")

print("Tabel di database Tiket_Kereta : ")
for tb in cursor:
    print(tb[0])

cursor.close()
connect.close()