from mysql import connector

connect = connector.connect(
    host = "localhost",
    user = "root",
    password = "",
    database = "Tiket_Kereta"
)

cursor = connect.cursor()

cursor.execute(
    """ 
    INSERT INTO kereta_api VALUES('Argo Bromo Anggrek', 'Gambir', 'Bojonegoro', 'SG815', '07:20:00', '09:35:00', 75000),
('Sembrani','Pasarturi','Lamongan','SG773','13:35:00','15:15:00',35000),
('Argo Sindoro','Gambir','Tawang','SG731','06:20:00','07:30:00',52000),
('Argo Lawu','Gambir','Solo Balapan','SG3720','08:10:00','09:55:00',95000),
('Taksaka','Gambir','Yogyakarta','SG493','17:25:00','19:55:00',85000),
('Purwojaya','Gambir','Cilacap','BA450','17:40:00','19:50:00',55000),
('Argo Wilis','Bandung','Mojokerto','BA552','06:15:00','09:00:00',65000),
('Gumarang','Pasar Senen','Pasar Turi','AE720','20:00:OO','06:45:00',43000),
('Argo Cheribon','Gambir','Tegal','AE450','07:05:00','19:55:00',67000),
('Bogowonto','Pasar Senen','Lempuyangan','BA230','17:50:00','13:50:00',85000),
('Sawunggalih','Pasar Senen','Kutoarjo','GA395','01:45:00','03:30:00',90000),
('Mataram','Pasar Senen','Solo Balapan','GA461','07:45:00','22:20:00',85000),
('Argo Parahyangan','Gambir','Bandung','GA492','08:00:00','23:00:00',52000),
('Argo Cheribon','Gambir','Cirebon','GA911','09:00:00','10:00:00',48000),
('Wijayakusuma','Ketapang','Gubeng','GA702','16:30:00','17:55:00',45000),
('Logawa','Jember','Gubeng','AI802','14:40:00','20:00:00',92000),
('Malabar','Bandung','Malang','AI821','06:15:00','12:00:00',75000),
('Ranggajati','Jember','Cirebon','AI815','07:00:00','07:30:00',63000),
('Kertanegara','Malang','Purwokerto','AI573','12:45:00','01:20:00',78000),
('Lodaya','Solo Balapan','Bandung','AI550','23:45:00','00:00:00',75000),
('Sancaka','Yogyakarta','Gubeng','6E5917','18:00:00','18:30:00',66500),
('Turangga','Bandung','Kertonoso','6E544','03:50:00','04:10:00',82000),
('Argo Dwipangga','Gambir','Klaten','6E0086','12:35:00','01:00:00',85000),
('Argo Sindoro','Gambir','Pekalongan','6E0954','04:25:00','04:55:00',55500),
('Brawijaya','Gambir','Malang','6E0745','15:30:00','16:00:00',85000) ;
    """
)

connect.commit()

cursor.execute("SELECT * FROM kereta_api;")

result = cursor.fetchall()

for data in result:
    print(data[0],'-',data[1],'-',data[2],'-',data[3],data[4],'-',data[5],'-',data[6])

cursor.close()
connect.close()